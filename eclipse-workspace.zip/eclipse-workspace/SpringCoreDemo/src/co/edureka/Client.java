package co.edureka;

import org.springframework.core.io.Resource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee eRef = new Employee();
		eRef.setEid(101);
		eRef.setEname("Rohit Saxena");
		eRef.setEaddress("Radbroke");
		
		System.out.println("Employee Details: " + eRef);
		
		//Spring Way by using IOC
		/*Resource resource = new ClassPathResource("employeebean.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
				
		Employee e1 = (Employee)factory.getBean("emp1");
		Employee e2 = factory.getBean("emp2",Employee.class);*/
		
		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("employeebean.xml");
		
		Employee e1 = (Employee)applicationContext.getBean("emp1");
		Employee e2 = applicationContext.getBean("emp2",Employee.class);
		
		System.out.println("Employee Details" + e1);
		System.out.println("Employee Details" + e2);		
}

}
