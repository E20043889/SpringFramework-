package org.rohit.springPackage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class DrawingApp {

	public static void main(String[] args) {
		//Triangle tringle = new Triangle();
		
		ApplicationContext  factory = new FileSystemXmlApplicationContext("spring.xml");
		Triangle triangle = (Triangle) factory.getBean("triangle");
		triangle.draw();

	}

}
